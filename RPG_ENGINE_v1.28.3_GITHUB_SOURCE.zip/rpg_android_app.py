from __future__ import annotations

from pathlib import Path
from threading import Thread

from kivy.app import App
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp, sp
from kivy.properties import ColorProperty, NumericProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen, ScreenManager, SlideTransition
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.graphics import Color, RoundedRectangle, Line

from engine import __version__
from engine.app.controller import AppController


BG = (0.082, 0.082, 0.082, 1)          # ChatGPT-like deep neutral
SURFACE = (0.125, 0.125, 0.125, 1)
SURFACE_2 = (0.17, 0.17, 0.17, 1)
BORDER = (0.24, 0.24, 0.24, 1)
TEXT = (0.93, 0.93, 0.93, 1)
MUTED = (0.62, 0.62, 0.62, 1)
ACCENT = (0.28, 0.72, 0.58, 1)
DANGER = (0.88, 0.32, 0.32, 1)


class RoundedPanel(BoxLayout):
    radius = NumericProperty(dp(18))
    fill = ColorProperty(SURFACE)
    outline = ColorProperty(BORDER)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            self._color = Color(rgba=self.fill)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[self.radius])
            self._line_color = Color(rgba=self.outline)
            self._line = Line(rounded_rectangle=(self.x, self.y, self.width, self.height, self.radius), width=0.7)
        self.bind(pos=self._sync, size=self._sync, fill=self._sync, outline=self._sync, radius=self._sync)

    def _sync(self, *_):
        self._color.rgba = self.fill
        self._rect.pos = self.pos
        self._rect.size = self.size
        self._rect.radius = [self.radius]
        self._line_color.rgba = self.outline
        self._line.rounded_rectangle = (self.x, self.y, self.width, self.height, self.radius)


class SoftButton(Button):
    fill = ColorProperty(SURFACE_2)
    pressed_fill = ColorProperty((0.22, 0.22, 0.22, 1))
    radius = NumericProperty(dp(14))

    def __init__(self, **kwargs):
        kwargs.setdefault("background_normal", "")
        kwargs.setdefault("background_down", "")
        kwargs.setdefault("background_color", (0, 0, 0, 0))
        kwargs.setdefault("color", TEXT)
        kwargs.setdefault("font_size", sp(14))
        super().__init__(**kwargs)
        with self.canvas.before:
            self._color = Color(rgba=self.fill)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[self.radius])
        self.bind(pos=self._sync, size=self._sync, fill=self._sync, radius=self._sync)

    def _sync(self, *_):
        self._color.rgba = self.pressed_fill if self.state == "down" else self.fill
        self._rect.pos = self.pos
        self._rect.size = self.size
        self._rect.radius = [self.radius]


class AccentButton(SoftButton):
    fill = ColorProperty(ACCENT)
    pressed_fill = ColorProperty((0.22, 0.58, 0.46, 1))
    color = ColorProperty((0.03, 0.08, 0.07, 1))


class GhostButton(SoftButton):
    fill = ColorProperty((0, 0, 0, 0))
    pressed_fill = ColorProperty(SURFACE_2)
    color = ColorProperty(TEXT)


class PillInput(TextInput):
    background_color = ColorProperty(SURFACE_2)
    foreground_color = ColorProperty(TEXT)
    hint_text_color = ColorProperty(MUTED)
    cursor_color = ColorProperty(ACCENT)
    padding = [dp(15), dp(12)]
    font_size = sp(14)
    multiline = False

    def __init__(self, **kwargs):
        kwargs.setdefault("background_normal", "")
        kwargs.setdefault("background_active", "")
        super().__init__(**kwargs)
        with self.canvas.before:
            self._color = Color(rgba=self.background_color)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(16)])
        self.bind(pos=self._sync, size=self._sync, background_color=self._sync)

    def _sync(self, *_):
        self._color.rgba = self.background_color
        self._rect.pos = self.pos
        self._rect.size = self.size


class BodyLabel(Label):
    color = ColorProperty(TEXT)
    font_size = sp(15)
    halign = "left"
    valign = "middle"
    text_size = (None, None)


class BaseScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app
        self.background_color = BG

    def show(self):
        self.opacity = 0
        Animation(opacity=1, duration=0.18, t="out_quad").start(self)


class HomeScreen(BaseScreen):
    def __init__(self, app, **kwargs):
        super().__init__(app, name="home", **kwargs)
        root = BoxLayout(orientation="vertical", padding=[dp(18), dp(20), dp(18), dp(12)], spacing=dp(14))
        title = Label(text="RPG Engine", color=TEXT, font_size=sp(30), bold=True, size_hint_y=None, height=dp(44), halign="left")
        title.bind(size=lambda *_: setattr(title, "text_size", title.size))
        root.add_widget(title)
        sub = Label(text="Yerel dünya simülasyonu · AI anlatım motoru", color=MUTED, font_size=sp(13), size_hint_y=None, height=dp(28), halign="left")
        sub.bind(size=lambda *_: setattr(sub, "text_size", sub.size))
        root.add_widget(sub)

        card = RoundedPanel(orientation="vertical", padding=dp(18), spacing=dp(12), size_hint_y=None, height=dp(176))
        card.add_widget(Label(text="Kaldığın yer", color=MUTED, font_size=sp(12), halign="left", size_hint_y=None, height=dp(22)))
        self.status = Label(text="Demo dünyası hazır", color=TEXT, font_size=sp(20), bold=True, halign="left", size_hint_y=None, height=dp(34))
        self.status.bind(size=lambda *_: setattr(self.status, "text_size", self.status.size))
        card.add_widget(self.status)
        self.meta = Label(text="AI: Demo / AI kapalı", color=MUTED, font_size=sp(12), halign="left", size_hint_y=None, height=dp(24))
        self.meta.bind(size=lambda *_: setattr(self.meta, "text_size", self.meta.size))
        card.add_widget(self.meta)
        start = AccentButton(text="Oyuna devam et", size_hint_y=None, height=dp(48))
        start.bind(on_release=lambda *_: self.app_ref.open_game())
        card.add_widget(start)
        root.add_widget(card)

        hint = Label(text="Senaryoları, AI modellerini ve API bağlantılarını aşağıdaki menüden yönetebilirsin.", color=MUTED, font_size=sp(13), halign="left", valign="top")
        hint.bind(size=lambda *_: setattr(hint, "text_size", hint.size))
        root.add_widget(hint)
        root.add_widget(Label())
        self.add_widget(root)

    def refresh(self):
        self.meta.text = f"AI: {self.app_ref.controller.provider_name} · Turn {self.app_ref.controller.turn}"


class GameScreen(BaseScreen):
    def __init__(self, app, **kwargs):
        super().__init__(app, name="game", **kwargs)
        root = BoxLayout(orientation="vertical", padding=[dp(12), dp(10), dp(12), dp(10)], spacing=dp(8))
        top = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        back = GhostButton(text="‹", size_hint_x=None, width=dp(46), font_size=sp(28))
        back.bind(on_release=lambda *_: self.app_ref.open_home())
        top.add_widget(back)
        self.title = Label(text="Oyun", color=TEXT, font_size=sp(18), bold=True, halign="left")
        self.title.bind(size=lambda *_: setattr(self.title, "text_size", self.title.size))
        top.add_widget(self.title)
        self.turn = Label(text="Turn 0", color=MUTED, font_size=sp(12), size_hint_x=None, width=dp(70))
        top.add_widget(self.turn)
        root.add_widget(top)

        self.scroll = ScrollView(do_scroll_x=False, bar_width=0)
        self.log = Label(text="", color=TEXT, font_size=sp(15), halign="left", valign="top", size_hint_y=None, padding=[dp(8), dp(8)])
        self.log.bind(texture_size=self._log_size)
        self.scroll.add_widget(self.log)
        root.add_widget(self.scroll)

        composer = RoundedPanel(orientation="horizontal", padding=[dp(6), dp(6)], spacing=dp(6), size_hint_y=None, height=dp(60), fill=(0.12, 0.12, 0.12, 1))
        self.input = PillInput(hint_text="Ne yapmak istiyorsun?", size_hint_x=1)
        self.input.bind(on_text_validate=lambda *_: self.submit())
        composer.add_widget(self.input)
        send = AccentButton(text="↑", size_hint_x=None, width=dp(48), font_size=sp(20))
        send.bind(on_release=lambda *_: self.submit())
        composer.add_widget(send)
        root.add_widget(composer)
        self.add_widget(root)

    def _log_size(self, *_):
        self.log.height = self.log.texture_size[1] + dp(24)
        self.log.text_size = (max(dp(20), self.scroll.width - dp(20)), None)

    def show(self):
        super().show()
        self.refresh()

    def refresh(self):
        self.turn.text = f"Turn {self.app_ref.controller.turn}"
        self.title.text = self.app_ref.controller.scenario_id

    def set_log(self, text):
        self.log.text = text
        Clock.schedule_once(lambda *_: setattr(self.scroll, "scroll_y", 0), 0)

    def append(self, text):
        if not text:
            return
        self.log.text = (self.log.text + "\n\n" if self.log.text else "") + text
        Clock.schedule_once(lambda *_: setattr(self.scroll, "scroll_y", 0), 0)

    def submit(self):
        text = self.input.text.strip()
        if not text or self.app_ref.busy:
            return
        self.input.text = ""
        self.app_ref.busy = True
        self.append(f"> {text}\n[İşleniyor…]")
        Thread(target=self.app_ref._submit_worker, args=(text,), daemon=True).start()


class ScenariosScreen(BaseScreen):
    def __init__(self, app, **kwargs):
        super().__init__(app, name="scenarios", **kwargs)
        self.list_box = BoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None)
        self.list_box.bind(minimum_height=self.list_box.setter("height"))
        scroll = ScrollView(do_scroll_x=False, bar_width=0)
        scroll.add_widget(self.list_box)
        root = BoxLayout(orientation="vertical", padding=[dp(18), dp(18), dp(18), dp(12)], spacing=dp(12))
        root.add_widget(self._heading("Senaryolar", "Kurulu dünyalar ve .rpgscenario paketleri"))
        import_btn = AccentButton(text="＋  Senaryo içe aktar", size_hint_y=None, height=dp(48))
        import_btn.bind(on_release=lambda *_: self.app_ref.import_scenario())
        root.add_widget(import_btn)
        root.add_widget(scroll)
        self.add_widget(root)

    def _heading(self, title, subtitle):
        box = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(76))
        box.add_widget(Label(text=title, color=TEXT, font_size=sp(27), bold=True, halign="left"))
        box.add_widget(Label(text=subtitle, color=MUTED, font_size=sp(12), halign="left"))
        return box

    def show(self):
        super().show()
        self.refresh()

    def refresh(self):
        self.list_box.clear_widgets()
        installed = self.app_ref.controller.installed_scenarios()
        if not installed:
            self.list_box.add_widget(Label(text="Henüz senaryo yok.\nDemo dünya ile başlayabilirsin.", color=MUTED, font_size=sp(14), size_hint_y=None, height=dp(70), halign="left"))
            return
        for item in installed:
            card = RoundedPanel(orientation="horizontal", padding=dp(12), spacing=dp(10), size_hint_y=None, height=dp(82))
            info = BoxLayout(orientation="vertical")
            info.add_widget(Label(text=item.name, color=TEXT, font_size=sp(15), bold=True, halign="left"))
            info.add_widget(Label(text=f"v{item.version} · {item.chapter_count} bölüm", color=MUTED, font_size=sp(11), halign="left"))
            card.add_widget(info)
            btn = SoftButton(text="Başlat", size_hint_x=None, width=dp(86))
            btn.bind(on_release=lambda *_a, sid=item.scenario_id: self.app_ref.open_scenario(sid))
            card.add_widget(btn)
            self.list_box.add_widget(card)


class AIScreen(BaseScreen):
    def __init__(self, app, **kwargs):
        super().__init__(app, name="ai", **kwargs)
        root = BoxLayout(orientation="vertical", padding=[dp(18), dp(18), dp(18), dp(12)], spacing=dp(12))
        root.add_widget(self._heading("AI Modelleri", "PocketPal mantığı: modeli seç, indir/import et, sonra aktif et."))

        self.provider = Label(text="Aktif sağlayıcı: Demo / AI kapalı", color=TEXT, font_size=sp(16), bold=True, size_hint_y=None, height=dp(32), halign="left")
        self.provider.bind(size=lambda *_: setattr(self.provider, "text_size", self.provider.size))
        root.add_widget(self.provider)

        local = RoundedPanel(orientation="vertical", padding=dp(14), spacing=dp(8), size_hint_y=None, height=dp(154))
        local.add_widget(Label(text="Local GGUF", color=TEXT, font_size=sp(15), bold=True, halign="left"))
        local.add_widget(Label(text="GGUF dosyasını uygulama depolamasına al. Native Android llama.cpp runtime hazır olduğunda doğrudan kullanılacak.", color=MUTED, font_size=sp(11), halign="left", valign="top"))
        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        pick = SoftButton(text="Model seç / içe aktar")
        pick.bind(on_release=lambda *_: self.app_ref.import_model())
        row.add_widget(pick)
        local.add_widget(row)
        root.add_widget(local)

        api = RoundedPanel(orientation="vertical", padding=dp(14), spacing=dp(8), size_hint_y=None, height=dp(240))
        api.add_widget(Label(text="API sağlayıcısı", color=TEXT, font_size=sp(15), bold=True, halign="left"))
        self.api_endpoint = PillInput(text="https://api.openai.com/v1", hint_text="Endpoint")
        self.api_model = PillInput(text="gpt-4.1-mini", hint_text="Model")
        self.api_key = PillInput(password=True, hint_text="API key")
        api.add_widget(self.api_endpoint); api.add_widget(self.api_model); api.add_widget(self.api_key)
        connect = AccentButton(text="API'ye bağlan", size_hint_y=None, height=dp(46))
        connect.bind(on_release=lambda *_: self.connect_api())
        api.add_widget(connect)
        root.add_widget(api)
        root.add_widget(Label(text="Gemini için endpoint otomatik ayarlanabilir; anahtar yalnızca uygulama içinde kullanılır.", color=MUTED, font_size=sp(11), halign="left"))
        root.add_widget(Label())
        self.add_widget(root)

    def _heading(self, title, subtitle):
        box = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(76))
        box.add_widget(Label(text=title, color=TEXT, font_size=sp(27), bold=True, halign="left"))
        box.add_widget(Label(text=subtitle, color=MUTED, font_size=sp(12), halign="left"))
        return box

    def show(self):
        super().show(); self.refresh()

    def refresh(self):
        self.provider.text = f"Aktif sağlayıcı: {self.app_ref.controller.provider_name}"

    def connect_api(self):
        try:
            self.app_ref.controller.set_openai_compatible(self.api_endpoint.text, self.api_key.text, self.api_model.text)
            self.app_ref.notify("API bağlantısı yapılandırıldı.")
            self.refresh()
        except Exception as exc:
            self.app_ref.notify(f"API ayarı başarısız: {exc}")


class SettingsScreen(BaseScreen):
    def __init__(self, app, **kwargs):
        super().__init__(app, name="settings", **kwargs)
        root = BoxLayout(orientation="vertical", padding=[dp(18), dp(18), dp(18), dp(12)], spacing=dp(12))
        root.add_widget(Label(text="Ayarlar", color=TEXT, font_size=sp(27), bold=True, size_hint_y=None, height=dp(48), halign="left"))
        for title, action in (
            ("Kaydet", app.save),
            ("Kayıt yükle", app.load),
            ("Senaryoları yönet", app.open_scenarios),
            ("AI modelleri", app.open_ai),
        ):
            b = SoftButton(text=title, size_hint_y=None, height=dp(52))
            b.bind(on_release=lambda *_a, fn=action: fn())
            root.add_widget(b)
        root.add_widget(Label(text=f"RPG Engine v{__version__}\nAndroid hedefi: API 36\nKivy 2.3.1", color=MUTED, font_size=sp(12), halign="left", valign="top"))
        root.add_widget(Label())
        self.add_widget(root)


class RPGEngineApp(App):
    title = "RPG Engine"

    def build(self):
        Window.clearcolor = BG
        Window.softinput_mode = "below_target"
        self.controller = AppController.demo()
        self.busy = False
        self._autosave_pending = False
        self._saf_import_in_progress = False
        self._model_import_in_progress = False

        self.manager = ScreenManager(transition=SlideTransition(duration=0.16))
        self.home = HomeScreen(self)
        self.game = GameScreen(self)
        self.scenarios = ScenariosScreen(self)
        self.ai = AIScreen(self)
        self.settings = SettingsScreen(self)
        for screen in (self.home, self.game, self.scenarios, self.ai, self.settings):
            self.manager.add_widget(screen)

        root = FloatLayout()
        root.add_widget(self.manager)
        root.add_widget(self._bottom_nav())
        self.manager.current = "home"
        Clock.schedule_once(lambda *_: self.home.refresh(), 0)
        return root

    def _bottom_nav(self):
        nav = RoundedPanel(orientation="horizontal", padding=[dp(6), dp(5)], spacing=dp(3), size_hint=(1, None), height=dp(66), pos_hint={"x": 0, "y": 0.0}, fill=(0.105, 0.105, 0.105, 0.98), radius=dp(22))
        for icon, label, target in (("⌂", "Ana", "home"), ("▣", "Oyun", "game"), ("◈", "Dünya", "scenarios"), ("✦", "AI", "ai"), ("•••", "Ayar", "settings")):
            b = GhostButton(text=f"{icon}\n{label}", font_size=sp(11))
            b.bind(on_release=lambda *_a, t=target: self.go(t))
            nav.add_widget(b)
        return nav

    def go(self, screen):
        current = self.manager.current
        self.manager.transition.direction = "left" if screen != "home" else "right"
        self.manager.current = screen
        target = self.manager.get_screen(screen)
        if hasattr(target, "show"):
            target.show()

    def open_home(self): self.go("home")
    def open_game(self): self.go("game")
    def open_scenarios(self): self.go("scenarios")
    def open_ai(self): self.go("ai")

    def notify(self, text):
        popup = Popup(title="RPG Engine", content=Label(text=text, color=TEXT, padding=[dp(14), dp(14)]), size_hint=(0.88, 0.28), background_color=SURFACE)
        popup.open()
        Clock.schedule_once(lambda *_: popup.dismiss(), 2.4)

    def _append(self, text):
        self.game.append(text)

    def _submit_worker(self, text):
        try:
            result = self.controller.submit(text)
        except Exception as exc:
            result = f"[İşlem başarısız: {exc}]"
        Clock.schedule_once(lambda *_: self._finish_submit(result), 0)

    def _finish_submit(self, result):
        self.busy = False
        if self._autosave_pending:
            self._autosave_pending = False
            self._autosave("deferred")
        marker = "\n[İşleniyor…]"
        if marker in self.game.log.text:
            self.game.log.text = self.game.log.text.rsplit(marker, 1)[0]
        self.game.append(result)
        self.game.refresh()
        self.home.refresh()

    def _initial_game(self):
        self.game.set_log("RPG Engine\n" + self.controller.submit("look"))
        self.game.refresh()

    def save(self):
        try:
            self.controller.save()
            self.notify("Oyun kaydedildi.")
        except Exception as exc:
            self.notify(f"Kaydetme başarısız: {exc}")

    def load(self):
        try:
            self.controller.load()
            self.game.set_log("Kayıt yüklendi.\n" + self.controller.submit("status"))
            self.game.refresh(); self.home.refresh()
        except Exception as exc:
            self.notify(f"Kayıt yüklenemedi: {exc}")

    def import_scenario(self):
        if self._saf_import():
            return
        chooser = FileChooserListView(filters=["*.zip", "*.rpgscenario.zip"], path=str(Path.home()))
        box = BoxLayout(orientation="vertical")
        box.add_widget(chooser)
        popup = Popup(title="Senaryo içe aktar", content=box, size_hint=(0.96, 0.88), background_color=SURFACE)
        actions = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(8))
        actions.add_widget(SoftButton(text="İptal", on_release=popup.dismiss))
        def do_import(*_):
            if not chooser.selection: return
            try:
                pack = self.controller.install_scenario(chooser.selection[0])
                popup.dismiss(); self.notify(f"{pack.name} yüklendi."); self.open_scenarios()
            except Exception as exc: self.notify(f"Import başarısız: {exc}")
        actions.add_widget(AccentButton(text="İçe aktar", on_release=do_import))
        box.add_widget(actions); popup.open()

    def _saf_import(self):
        if self._saf_import_in_progress: return True
        try:
            from rpg_android_file_picker import open_scenario_document
        except ImportError:
            return False
        self._saf_import_in_progress = True
        try:
            launched = open_scenario_document(self._on_saf_import)
        except Exception as exc:
            self._saf_import_in_progress = False; self.notify(str(exc)); return False
        if not launched: self._saf_import_in_progress = False
        return launched

    def _on_saf_import(self, path):
        Clock.schedule_once(lambda *_: self._finish_saf_import(path), 0)

    def _finish_saf_import(self, path):
        self._saf_import_in_progress = False
        try:
            pack = self.controller.install_scenario(path)
            self.notify(f"Senaryo yüklendi: {pack.name}"); self.open_scenarios()
        except Exception as exc:
            self.notify(f"Import başarısız: {exc}")

    def open_scenario(self, scenario_id):
        try:
            pack = self.controller.load_installed_scenario(scenario_id)
            self.controller.start_scenario(pack)
            self._initial_game(); self.open_game()
        except Exception as exc:
            self.notify(f"Senaryo başlatılamadı: {exc}")

    def import_model(self):
        if self._model_import_in_progress: return
        try:
            from rpg_android_file_picker import open_model_document
        except ImportError:
            self._desktop_model_picker(); return
        self._model_import_in_progress = True
        try:
            launched = open_model_document(self._on_model_import)
        except Exception as exc:
            self._model_import_in_progress = False; self.notify(str(exc)); return
        if not launched:
            self._model_import_in_progress = False; self._desktop_model_picker()

    def _desktop_model_picker(self):
        chooser = FileChooserListView(filters=["*.gguf"], path=str(Path.home()))
        box = BoxLayout(orientation="vertical"); box.add_widget(chooser)
        popup = Popup(title="GGUF model seç", content=box, size_hint=(0.96, 0.88), background_color=SURFACE)
        actions = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(8))
        actions.add_widget(SoftButton(text="İptal", on_release=popup.dismiss))
        def choose(*_):
            if not chooser.selection: return
            popup.dismiss(); self._activate_local_model(chooser.selection[0])
        actions.add_widget(AccentButton(text="Modeli seç", on_release=choose))
        box.add_widget(actions); popup.open()

    def _on_model_import(self, path):
        Clock.schedule_once(lambda *_: self._finish_model_import(path), 0)

    def _finish_model_import(self, path):
        self._model_import_in_progress = False
        self._activate_local_model(path)

    def _activate_local_model(self, path):
        try:
            self.controller.set_local_model(path)
            self.notify("Local GGUF seçildi. Native Android runtime hazır olduğunda model çalıştırılabilir.")
            self.ai.refresh()
        except Exception as exc:
            self.notify(f"Local model henüz çalıştırılamadı: {exc}")

    def on_pause(self):
        self._autosave("pause")
        return True

    def on_stop(self):
        self._autosave("stop")

    def _autosave(self, reason):
        if self.busy:
            self._autosave_pending = True; return
        try: self.controller.save()
        except Exception:
            pass


if __name__ == "__main__":
    RPGEngineApp().run()
