## Current Release: v1.28.3

Android/Colab stabilization: persistent build cache, non-interactive SDK licensing, aligned Android entrypoint/tests, and verified source packaging.
- Verified regression baseline: **435 passed**; mutation smoke **3/3**; Android readiness **PASS**.


## Historical Release Marker — v1.28.0

- Standalone Android UI shell rebuilt around a dark ChatGPT-like visual system with rounded Apple-style controls and lightweight transitions.
- Added in-app AI provider screen for local GGUF model selection and OpenAI-compatible APIs.
- Added Android SAF GGUF model import alongside scenario import.
- Added generic OpenAI-compatible AI adapter while preserving the deterministic AIAdapter boundary.
- Added canonical Scenario Data Pack Master Specification v3.0 aligned with the current engine authoring/runtime boundary.
- Native Android llama.cpp runtime remains a separate integration task; no Termux dependency is introduced.
## Current Release — v1.27.0

- Android application-readiness milestone implemented.
- Target API 36; Kivy 2.3.1 pinned; SAF scenario import; Android readiness verifier.
- Core test suite: 432 passing under the dependency-free runner.
- APK/device verification remains environment-dependent and is explicitly unchecked until a real build/device test is performed.

# RPG Engine

A private, local-first, text-based **RPG simulation engine** inspired by AI Dungeon, but explicitly designed to be a real game engine rather than a story generator.

## Current version

- Checkpoint: **v1.26.0**
- Engine: **1.24.1**
- Save format: **v5**
- Verified tests: **428 passed**
- Android target: **standalone APK**
- End-user Termux requirement: **none**

## Read this first

**New AI/developer:** read `AI_START_HERE.md` first. It contains the project mission, Android/local-AI requirements, current verified state, critical known issue, and canonical reading order.

The complete product roadmap is `docs/MASTER_ROADMAP.md`. `PROJECT_HANDOFF.md` and `PROJECT_CHECKPOINT.md` contain the current transfer state.

## Product target

The final application is an Android APK. Users should be able to install it directly, manage scenarios, start campaigns, play, save/load, and choose cloud or local AI without installing Termux or Python.

Local AI is intended to work like an app-managed local model system: the user downloads a supported GGUF model from inside the app, the model is stored in app-private storage, and an Android-native llama.cpp runtime performs inference on-device. Gemini remains an optional cloud provider. Google Colab is a proposed build environment for APK generation, not an end-user runtime.

## Architecture

The deterministic engine owns authoritative state. AI receives bounded context and returns structured proposals. The engine validates and atomically applies permitted effects. Scenario canon is read-only, and memory/knowledge visibility is enforced.

```text
Player action
  -> parser
  -> authoritative engine state/rules
  -> memory/scenario/NPC retrieval
  -> bounded AI context
  -> structured AI proposal
  -> validation/security gate
  -> atomic state update
  -> memory/event/quest updates
  -> save
```

## Current verification

v1.26.0 is a full source hardening pass: AI provider diagnostics, scenario retrieval indexing, context-budget diagnostics, and Android lifecycle/import robustness were improved while preserving the deterministic engine contract. Test infrastructure and mutation detection remain part of the release baseline. The final verified test count is recorded in PROJECT_CHECKPOINT.md and docs/TESTING.md.

## Current development state

The former Scenario Registry/Retriever/Configuration start/load wiring issue is fixed and regression-tested. v1.19.0 added deterministic NPC schedules, repeating/cyclic routines, and per-turn movement through the shared validation gate. v1.24.0 closes the engine-memory scalability gap with indexed deterministic retrieval, lossless recent-memory archiving, automatic maintenance, and 5,000-record stress coverage. v1.26.0 hardens the test infrastructure and adds mutation-detection evidence. Hostile NPC retaliation remains part of the prior Gameplay Core baseline.

## Documentation

| File | Purpose |
|---|---|
| `AI_START_HERE.md` | New-AI/developer entry point |
| `docs/MASTER_ROADMAP.md` | Canonical product goal + complete roadmap + verified status |
| `PROJECT_HANDOFF.md` | Current transfer/development instructions |
| `PROJECT_CHECKPOINT.md` | Current checkpoint and immediate priorities |
| `docs/CONSTITUTION.md` | Binding project rules |
| `docs/ARCHITECTURE.md` | Architecture and gameplay loop |
| `docs/DATA_MODELS.md` | Data contracts |
| `docs/SCENARIO_DATA_FORMAT.md` | Scenario pack specification |
| `docs/AI_SECURITY_SPEC.md` | AI security boundary |
| `docs/AI_EXECUTION_POLICY.md` | AI transaction policy |
| `docs/DECISIONS.md` | Architecture decisions |
| `docs/TESTING.md` | Test architecture, release checks, and mutation smoke policy |

Historical documents may remain in the repository for traceability; they are not the current checkpoint unless explicitly identified as such.


## v1.26.0 — Full Source Hardening

- Dependency-free runner rejects async tests and accidental return values instead of silently accepting them.
- Runner regression suite covers pass/fail/import/fixture/async/return-value behavior.
- `tools/mutation_smoke.py` detects three deliberate critical validation regressions.
- Release verification now requires pytest, stdlib runner, mutation smoke, compileall, scenario validation, and clean-package revalidation.

## Audit and handoff

The project also contains the complete forensic audit of the preceding v1.16.0 package and a v1.17 reconciliation:

- `docs/audits/RPG_ENGINE_FULL_AUDIT_REPORT_v1.16.0.md` — original Claude audit, preserved verbatim
- `docs/AUDIT_FOLLOWUP_v1.17.0.md` — current interpretation and confirmed carry-forward findings

**Current status:** scenario runtime dependency wiring is fixed. Android storage/lifecycle still require real-device verification.



## v1.24.0 — Gameplay Core: hostile NPC retaliation

The first Gate B combat slice is now engine-authoritative: hostile NPCs can retaliate after a player attack or technique when they survive the hit. Retaliation is emitted as part of the same atomic effect batch, so it cannot partially apply. The threshold is deterministic (`disposition <= -25`) and damage is `max(1, npc.attack_power - player.defense)`. Non-hostile NPCs do not retaliate.


## v1.24.0 — Memory Lifecycle + Indexed Retrieval

- Memory retrieval now uses derived store/entity/location/event/tag/trigram indexes before applying the existing deterministic scorer.
- Existing substring ranking semantics remain intact; short-term queries use a conservative fallback.
- Recent memory has a lossless archive tier. Archived records remain persisted and can be explicitly retrieved but are excluded from normal context retrieval.
- GameSession performs deterministic memory maintenance every 25 turns once memory reaches 500 records, archiving recent records older than the configured 100-turn retention window.
- Save format remains v5 because the new memory tier field is additive and backward-compatible.
- Added indexed retrieval, archive round-trip, automatic maintenance, and 5,000-record long-session regression coverage.
- Engine Completion remains open for the final invariant/persistence/scenario/AI verification gates.
