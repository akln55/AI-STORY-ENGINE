## Current Release: v1.28.3

Android/Colab stabilization: persistent build cache, non-interactive SDK licensing, aligned Android entrypoint/tests, and verified source packaging.


## Historical Release Marker — v1.28.0

- Standalone Android UI shell rebuilt around a dark ChatGPT-like visual system with rounded Apple-style controls and lightweight transitions.
- Added in-app AI provider screen for local GGUF model selection and OpenAI-compatible APIs.
- Added Android SAF GGUF model import alongside scenario import.
- Added generic OpenAI-compatible AI adapter while preserving the deterministic AIAdapter boundary.
- Added canonical Scenario Data Pack Master Specification v3.0 aligned with the current engine authoring/runtime boundary.
- Native Android llama.cpp runtime remains a separate integration task; no Termux dependency is introduced.
## Current Release — v1.27.0

- Android application-readiness milestone implemented.
- Target API 36; Kivy 2.3.1 pinned; SAF scenario import; Android readiness verifier.
- Core test suite: 432 passing under the dependency-free runner.
- APK/device verification remains environment-dependent and is explicitly unchecked until a real build/device test is performed.

# AI START HERE — RPG Engine v1.26.0

If you are a new AI/developer receiving this ZIP, read this file first. It is intentionally self-contained so the project owner does not need to repeat the project's purpose or constraints in chat.

## What this project is

This is a private, local-first, text-based RPG **simulation engine**, inspired by AI Dungeon but explicitly not intended to be a chatbot that merely writes stories. The engine owns authoritative state and deterministic rules. AI is an untrusted narrator/proposer.

The intended final product is an Android APK. The end user must **not** need Termux, Python, a terminal, or any other external runtime. Google Colab may be used as a build environment for producing the APK.

## Local AI requirement

The app is intended to support a PocketPal-like local-model experience inside the RPG application itself:

1. User opens the APK.
2. User chooses a local model.
3. App downloads a supported GGUF model.
4. Model is stored in app-private Android storage.
5. Android-native llama.cpp loads the model.
6. RPG Engine sends bounded context through the AIAdapter.
7. Inference happens on-device without requiring an API.

Gemini and other providers may remain available as optional cloud/custom providers. Local AI must not become a requirement for the deterministic engine.

## Core architecture rule

```text
Player -> Parser -> Engine -> Context -> AI proposal -> Validation -> State -> Memory -> Save
```

AI never becomes the authority. It cannot directly write GameState, saves, DB, scenario files, execute code, or bypass validation.

## Current verification evidence

- Clean ZIP extraction: required and verified for each release package
- Test suite: see `PROJECT_CHECKPOINT.md` for the exact current verified count
- Dependency-free runner: required
- Mutation smoke: **3/3 critical mutations detected**
- Compile check: passed
- Scenario validation: passed
- 200-turn deterministic simulation: present
- 1000-turn deterministic simulation: present
- Android Kivy shell: present
- Gemini adapter: present
- Development llama.cpp adapters: present
- Scenario packs/chapter infrastructure: present
- Memory system: present
- NPC encounter/dialogue foundations: present
- Quest/event foundations: present

## Critical known issue — resolved in current remediation pass

The initial v1.17 package had a scenario runtime integration omission: the application start/load paths did not pass `ScenarioRegistry`, `ScenarioRetriever`, and `ScenarioConfiguration` into `GameSession`. This has now been fixed and is covered by AppController start/load regression tests. Do not regress this wiring in future refactors.

## What is not yet the final product

The following are still future work: semantic retrieval, advanced context compression, full scenario authoring workflow, save manager, settings, model manager, Android-native llama.cpp runtime, APK/device verification, and final campaign QA. Deterministic indexed retrieval and lossless recent-memory archiving are implemented in v1.24.0; NPC Living World Core is complete for deterministic engine scope in v1.24.0. v1.26.0 performs a broad source hardening pass across AI reliability, context budgets, scenario retrieval, and Android lifecycle/import handling. See `docs/TESTING.md` for the release verification contract.

## Canonical reading order

1. `AI_START_HERE.md`
2. `docs/CONSTITUTION.md`
3. `docs/MASTER_ROADMAP.md`
4. `PROJECT_HANDOFF.md`
5. `PROJECT_CHECKPOINT.md`
6. `docs/ARCHITECTURE.md`
7. `docs/DATA_MODELS.md`
8. `docs/SCENARIO_DATA_FORMAT.md`
9. Relevant specs under `docs/`
10. Source + tests

## Development discipline

Do not redesign from scratch. Audit the current ZIP first. Work only on the agreed phase. After changes: add focused tests, run the full regression suite, compile/package checks, extract the final ZIP into a fresh directory, run the suite again, and update the canonical handoff/checkpoint documentation in the same change.


## Audit history and current interpretation

A full independent forensic audit was performed on the preceding `v1.16.0` package by Claude. The original 1,181-line report is preserved verbatim at:

`docs/audits/RPG_ENGINE_FULL_AUDIT_REPORT_v1.16.0.md`

The v1.17 follow-up is:

`docs/AUDIT_FOLLOWUP_v1.17.0.md`

The most important v1.16 audit finding — missing scenario dependency propagation into the real application start/load path — has been fixed in the v1.17 remediation pass and is covered by AppController-level regression tests. The `pick up` parser target bug, quest-prerequisite validation bypass, and scenario-bootstrap quest-field loss were also fixed.

Do not treat the historical v1.16 test counts or environment limitations as current facts. The current v1.18 pytest verification is **399 passed**.

## Product constraints that must not be lost during future work

- Final product is a standalone Android APK.
- The end user does not install or use Termux, Python, a shell, or another runtime.
- Google Colab is a proposed APK build environment only.
- Local AI means an in-app model manager downloads GGUF models, stores them on-device, and an Android-native llama.cpp runtime performs inference locally.
- Gemini/cloud providers remain optional.
- The engine remains authoritative; AI remains an untrusted proposal/narration layer.
- Future work must preserve the canonical handoff/roadmap state in the same ZIP.


## v2.0 execution authority

`docs/V2_MASTER_PLAN.md` is the canonical execution plan. The active gate is **Engine Completion**. Prioritize foundational campaign reliability over additional NPC simulation until Gate A exits.
