"""Thin application controller shared by Android and future desktop UI.

UI code never mutates GameState directly. All gameplay goes through GameSession.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from engine.ai.gemini_adapter import GeminiAdapter
from engine.ai.llama_cpp_adapter import LlamaCppAdapter, LlamaCppConfig
from engine.ai.openai_compatible_adapter import OpenAICompatibleAdapter
from engine.core.game import GameSession
from engine.demo import build_demo_state
from engine.scenario.configuration import ScenarioConfiguration
from engine.scenario.loader import ScenarioPack
from engine.scenario.manager import ScenarioManager
from engine.persistence.saves import load_session, save_session


@dataclass
class AppController:
    session: GameSession
    scenario_id: str = "demo-bootstrap"
    scenario_pack: ScenarioPack | None = None
    scenario_config: ScenarioConfiguration | None = None

    @classmethod
    def demo(cls, adapter=None) -> "AppController":
        return cls(GameSession(build_demo_state(), adapter=adapter))

    @property
    def turn(self) -> int:
        return self.session.clock.turn

    @property
    def location_name(self) -> str:
        location = self.session.state.character.location_id
        return self.session.state.world.locations.get(location, location)

    def installed_scenarios(self):
        return ScenarioManager().list_installed()

    def load_installed_scenario(self, scenario_id: str) -> ScenarioPack:
        return ScenarioManager().load(scenario_id)

    def install_scenario(self, archive: Path | str, *, replace: bool = False) -> ScenarioPack:
        manager = ScenarioManager()
        pack = manager.install(archive, replace=replace)
        return pack

    def start_scenario(self, pack: ScenarioPack, *, mode="sequential", selected_pack_ids=None, start_chapter=None, adapter=None) -> None:
        self.session = GameSession.from_scenario_pack(
            pack, adapter=adapter, mode=mode, selected_pack_ids=selected_pack_ids, start_chapter=start_chapter
        )
        config = self.session.scenario_configuration
        self.scenario_id = pack.scenario_id
        self.scenario_pack = pack
        self.scenario_config = config

    def set_gemini(self, api_key: str, model: str = "") -> None:
        self.session.adapter = GeminiAdapter(api_key, model=model or "gemini-3.6-flash")

    def set_local_model(self, model_path: str, *, n_ctx: int = 4096, max_tokens: int = 512,
                        temperature: float = 0.7, n_gpu_layers: int = 0) -> None:
        self.session.adapter = LlamaCppAdapter(LlamaCppConfig(
            model_path=model_path, n_ctx=n_ctx, max_tokens=max_tokens,
            temperature=temperature, n_gpu_layers=n_gpu_layers,
        ))

    def set_openai_compatible(self, endpoint: str, api_key: str, model: str = "") -> None:
        self.session.adapter = OpenAICompatibleAdapter(endpoint, api_key, model)

    @property
    def provider_name(self) -> str:
        adapter = self.session.adapter
        if adapter is None:
            return "Demo / AI kapalı"
        name = adapter.__class__.__name__
        return {
            "GeminiAdapter": "Gemini",
            "LlamaCppAdapter": "Local GGUF",
            "OpenAICompatibleAdapter": "OpenAI-compatible API",
        }.get(name, name)

    def submit(self, text: str) -> str:
        text = text.strip()
        if not text:
            return ""
        return self.session.handle_input(text)

    def save(self, slot: str = "slot1", save_dir: Path | None = None) -> Path:
        return save_session(self.session, slot=slot, save_dir=save_dir)

    def load(self, slot: str = "slot1", save_dir: Path | None = None, adapter=None) -> None:
        context = None
        if self.scenario_pack is not None:
            from engine.scenario.context import ScenarioContext
            context = ScenarioContext(self.scenario_pack, self.scenario_config) if self.scenario_config is not None else None
        self.session = load_session(
            slot=slot, save_dir=save_dir, adapter=adapter, scenario_id=self.scenario_id,
            scenario_context=context,
        )
