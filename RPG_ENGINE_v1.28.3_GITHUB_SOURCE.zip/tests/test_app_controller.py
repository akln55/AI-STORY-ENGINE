from engine.ai.fake import FakeAdapter
from engine.app.controller import AppController


def test_controller_uses_engine_for_commands():
    c = AppController.demo(adapter=FakeAdapter())
    out = c.submit("look")
    assert "Sleepy Village" in out


def test_controller_save_load_roundtrip(tmp_path):
    c = AppController.demo(adapter=FakeAdapter())
    c.submit("go forest")
    c.save(save_dir=tmp_path)
    restored = AppController.demo(adapter=FakeAdapter())
    restored.load(save_dir=tmp_path)
    assert restored.location_name == "Whispering Forest"


def test_controller_reports_turn():
    c = AppController.demo(adapter=FakeAdapter())
    assert c.turn == 0
    c.submit("look")
    assert c.turn == 0  # meta commands do not advance the game clock
