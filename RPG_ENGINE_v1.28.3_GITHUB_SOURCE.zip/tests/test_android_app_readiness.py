"""Static/runtime-safe checks for the Android packaging contract."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_buildozer_targets_current_play_api():
    spec = (ROOT / "buildozer.spec").read_text()
    assert "version = 1.28.3" in spec
    assert "android.api = 36" in spec
    assert "READ_EXTERNAL_STORAGE" not in spec


def test_root_entrypoint_is_android_app():
    main = (ROOT / "main.py").read_text()
    assert "from rpg_android_app import RPGEngineApp" in main
    assert "RPGEngineApp().run()" in main


def test_android_uses_saf_picker():
    source = (ROOT / "rpg_android_app.py").read_text()
    picker = (ROOT / "rpg_android_file_picker.py").read_text()
    assert "open_scenario_document" in source
    assert "ACTION_OPEN_DOCUMENT" in picker
    assert "_saf_import" in source


def test_android_import_does_not_request_legacy_storage_permission():
    spec = (ROOT / "buildozer.spec").read_text()
    assert "WRITE_EXTERNAL_STORAGE" not in spec
    assert "READ_EXTERNAL_STORAGE" not in spec


def test_android_ui_has_model_manager_and_provider_screens():
    source = (ROOT / "rpg_android_app.py").read_text()
    assert "class AIScreen" in source
    assert "import_model" in source
    assert "set_openai_compatible" in source
    assert "Local GGUF" in source

def test_generic_api_adapter_imports_without_optional_dependencies():
    from engine.ai.openai_compatible_adapter import OpenAICompatibleAdapter
    adapter = OpenAICompatibleAdapter("https://example.com/v1", "key", "model")
    assert adapter.capabilities.structured_json is True


def test_android_uses_model_saf_picker():
    source = (ROOT / "rpg_android_app.py").read_text()
    picker = (ROOT / "rpg_android_file_picker.py").read_text()
    assert "open_model_document" in source
    assert ".gguf" in picker
    assert 'subdir="models"' in picker
