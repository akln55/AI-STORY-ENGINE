from rpg_android_app import RPGEngineApp


if __name__ == "__main__":
    RPGEngineApp().run()
