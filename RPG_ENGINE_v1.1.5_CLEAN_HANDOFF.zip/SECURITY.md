# Security Policy

This repository is public and is used as a build source for RPG Engine.

## Never commit secrets

Do not commit:
- API keys
- access tokens
- passwords
- private signing keys or certificates
- service-account credentials
- `.env` files containing secrets
- personal data
- local save data
- downloaded GGUF/model files
- generated Android APK/AAB artifacts

Use GitHub Actions Secrets when CI credentials are actually required.

## Native runtime rule

The Android `llama-server` executable is a build artifact. It is not committed to source control. The pinned source revision and reproducible build script are committed instead.

## Public repository rule

Assume every committed file is publicly visible.

## Exposed secret response

Revoke/rotate the exposed credential first, then remove the secret from repository history before considering the repository clean again.
